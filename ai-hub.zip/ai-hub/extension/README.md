# AI Hub Memória — extensão Chrome / Edge / Brave

Extensão Manifest V3 **original** (não é um fork de produto da loja). Serve Qwen, DeepSeek, GLM/Z.ai/智谱清言 e Mistral com a **mesma biblioteca de memórias**.

Não copiámos código de DeepSider, SideAll, AIPRM, Superpower ChatGPT, Better DeepSeek, etc. Essas extensões ou são fechadas, ou não cobrem os quatro chats + memória + ficheiros.

## Instalar (modo programador)

1. Chrome / Edge / Brave → `chrome://extensions/`
2. Activar **Modo de programador**
3. **Carregar sem compactação** → escolher esta pasta `ai-hub-extension`
4. Abrir https://chat.qwen.ai, https://chat.deepseek.com, https://chat.z.ai ou https://chat.mistral.ai já com login
5. Canto inferior direito: dock **AI Hub**

Firefox: o `sidePanel` e o `declarativeNetRequest` diferem; usa Chrome/Edge para esta versão.

## O que faz

No site oficial:

- **Inserir memória** — prefixa as memórias activas na caixa de texto
- **Substituir campo** — limpa e põe só memória
- **Código → ficheiros** — detecta ` ```python ` etc. e descarrega `.py`, `.java`, `.md`, …
- Botão **guardar** em cada `<pre>`
- **Painel** — biblioteca de memórias + atalhos para os quatro chats

O painel lateral tenta iframe (a extensão remove `X-Frame-Options` / CSP **apenas em sub-frames**). Se o site continuar em branco, abre **Nova janela**: a injecção corre no separador real, que é o caminho fiável.

## Porque não quatro extensões

A memória tem de ser a mesma nos quatro modelos. Quatro pacotes = quatro cópias a dessincronizar. Os adaptadores estão em `content/sites.js`; se um site mudar a UI, editas só os selectores desse bloco.

## Extensões já existentes (o que aproveitar)

Usa **à parte**, sem as modificarmos (código fechado ou licença alheia):

| Extensão | Útil para | Falha para o teu caso |
|---|---|---|
| [PromptVault](https://github.com/marcko80/PromptVault) / [Open Prompt Manager](https://github.com/jonathanbertholet/promptmanager) | Biblioteca de prompts | Pouca ou nenhuma memória contínua + export de código |
| [ai-chat-exporter](https://github.com/Rat-S/ai-chat-exporter) | Exportar conversa MD/JSON | Não gera .py/.docx nem injeta memória |
| [QuickPrompts](https://github.com/rickoslyder/QuickPrompts) | Botões de snippet | Sem monitor de respostas |
| DeepSider / SideAll / AI Sider | Sidebar com contas oficiais | Produto fechado; sem o teu pipeline de ficheiros |
| Better DeepSeek | Ferramentas só no DeepSeek | Um único modelo |
| MultAI / ChatClub | Vários iframes | Não gerem memória nem DOCX/XLS |

Podes instalar o *ai-chat-exporter* **em paralelo** se quiseres o transcript completo em Markdown.

## Limites honestos

- Selectores partem quando o site redesenha o composer. Aí actualiza `content/sites.js`.
- A extensão **não lê o DOM dentro do iframe** de outro origin de forma estável; o dock no separador oficial é a fonte de verdade.
- DOCX/XLSX/PDF “a sério” continuam no hub Python (`ai-hub-local`). A extensão descarrega texto e código; cola no Monitor do hub se precisares de Office.
- Remover CSP em sub-frames é o truque das sidebars da loja. Usa só no teu browser.
