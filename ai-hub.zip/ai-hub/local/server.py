#!/usr/bin/env python3
"""Hub local para Qwen, DeepSeek, GLM e Mistral.

Serve a UI, persiste memórias, faz proxy OpenAI-compatível e exporta
ficheiros (md, txt, py, java, html, json, csv, docx, xlsx, pdf).
"""

from __future__ import annotations

import io
import json
import os
import re
import urllib.error
import urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from datetime import datetime
from typing import Any

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"
EXPORTS = ROOT / "exports"
DATA = ROOT / "data"
MEMORIES_FILE = DATA / "memories.json"

EXPORTS.mkdir(exist_ok=True)
DATA.mkdir(exist_ok=True)

PROVIDERS: dict[str, dict[str, str]] = {
    "qwen": {
        "name": "Qwen",
        "base": "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
        "base_cn": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "model": "qwen-plus",
        "chat": "https://chat.qwen.ai",
    },
    "deepseek": {
        "name": "DeepSeek",
        "base": "https://api.deepseek.com/v1",
        "model": "deepseek-chat",
        "chat": "https://chat.deepseek.com",
    },
    "glm": {
        "name": "GLM / Z.ai",
        "base": "https://api.z.ai/api/paas/v4",
        "base_cn": "https://open.bigmodel.cn/api/paas/v4",
        "model": "glm-4.5-flash",
        "chat": "https://chat.z.ai",
    },
    "mistral": {
        "name": "Mistral",
        "base": "https://api.mistral.ai/v1",
        "model": "mistral-small-latest",
        "chat": "https://chat.mistral.ai",
    },
}

SAFE_NAME = re.compile(r"[^A-Za-z0-9._-]+")


def safe_filename(name: str, default: str = "export") -> str:
    name = (name or default).strip() or default
    name = SAFE_NAME.sub("_", name)[:80]
    return name or default


def json_bytes(obj: Any, code: int = 200) -> tuple[int, bytes, str]:
    raw = json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8")
    return code, raw, "application/json; charset=utf-8"


def load_memories() -> list[dict]:
    if not MEMORIES_FILE.exists():
        return []
    try:
        data = json.loads(MEMORIES_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save_memories(items: list[dict]) -> None:
    MEMORIES_FILE.write_text(
        json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def write_text_file(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def export_markdown_or_code(path: Path, content: str, title: str = "") -> None:
    write_text_file(path, content)


def export_docx(path: Path, content: str, title: str) -> None:
    from docx import Document
    from docx.shared import Pt

    doc = Document()
    doc.add_heading(title or "Exportação", level=1)
    for block in content.split("\n\n"):
        p = doc.add_paragraph(block)
        for run in p.runs:
            run.font.size = Pt(11)
    doc.save(str(path))


def export_xlsx(path: Path, content: str, title: str) -> None:
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = (title or "Dados")[:31]
    lines = content.splitlines() or [content]
    # TSV / CSV simples
    if any("\t" in ln or ";" in ln or ("," in ln and ln.count(",") >= 1) for ln in lines[:5]):
        for r, line in enumerate(lines, 1):
            if "\t" in line:
                cols = line.split("\t")
            elif ";" in line:
                cols = line.split(";")
            else:
                cols = [c.strip() for c in line.split(",")]
            for c, val in enumerate(cols, 1):
                ws.cell(r, c, val)
    else:
        ws.cell(1, 1, title or "Conteúdo")
        for r, line in enumerate(lines, 2):
            ws.cell(r, 1, line)
    wb.save(str(path))


def export_pdf(path: Path, content: str, title: str) -> None:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Preformatted, Spacer
    from reportlab.lib.enums import TA_LEFT
    from xml.sax.saxutils import escape

    doc = SimpleDocTemplate(
        str(path),
        pagesize=A4,
        leftMargin=18 * mm,
        rightMargin=18 * mm,
        topMargin=16 * mm,
        bottomMargin=16 * mm,
        title=title or "Exportação",
    )
    styles = getSampleStyleSheet()
    heading = styles["Heading1"]
    body = ParagraphStyle(
        "BodyPT",
        parent=styles["Normal"],
        fontName="Times-Roman",
        fontSize=11,
        leading=15,
        alignment=TA_LEFT,
    )
    code = ParagraphStyle(
        "CodePT",
        parent=styles["Code"],
        fontName="Courier",
        fontSize=8.5,
        leading=11,
    )
    story = [Paragraph(escape(title or "Exportação"), heading), Spacer(1, 8)]
    looks_like_code = content.count("\n") > 3 and (
        "def " in content or "class " in content or "function " in content or "```" in content
    )
    if looks_like_code:
        story.append(Preformatted(content[:60000], code))
    else:
        for para in content.split("\n\n"):
            story.append(Paragraph(escape(para).replace("\n", "<br/>"), body))
            story.append(Spacer(1, 6))
    doc.build(story)


EXPORT_HANDLERS = {
    "md": (".md", export_markdown_or_code),
    "markdown": (".md", export_markdown_or_code),
    "txt": (".txt", export_markdown_or_code),
    "py": (".py", export_markdown_or_code),
    "python": (".py", export_markdown_or_code),
    "java": (".java", export_markdown_or_code),
    "js": (".js", export_markdown_or_code),
    "ts": (".ts", export_markdown_or_code),
    "html": (".html", export_markdown_or_code),
    "css": (".css", export_markdown_or_code),
    "json": (".json", export_markdown_or_code),
    "csv": (".csv", export_markdown_or_code),
    "sql": (".sql", export_markdown_or_code),
    "xml": (".xml", export_markdown_or_code),
    "yaml": (".yaml", export_markdown_or_code),
    "yml": (".yml", export_markdown_or_code),
    "sh": (".sh", export_markdown_or_code),
    "rs": (".rs", export_markdown_or_code),
    "go": (".go", export_markdown_or_code),
    "c": (".c", export_markdown_or_code),
    "cpp": (".cpp", export_markdown_or_code),
    "kt": (".kt", export_markdown_or_code),
    "swift": (".swift", export_markdown_or_code),
    "rb": (".rb", export_markdown_or_code),
    "php": (".php", export_markdown_or_code),
    "r": (".r", export_markdown_or_code),
    "docx": (".docx", export_docx),
    "xlsx": (".xlsx", export_xlsx),
    "xls": (".xlsx", export_xlsx),
    "pdf": (".pdf", export_pdf),
}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEB), **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            return json.loads(raw.decode("utf-8") or "{}")
        except json.JSONDecodeError:
            return {}

    def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        if extra:
            for k, v in extra.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/api/health":
            code, body, ctype = json_bytes({"ok": True, "providers": list(PROVIDERS)})
            return self._send(code, body, ctype)
        if path == "/api/memories":
            code, body, ctype = json_bytes({"memories": load_memories()})
            return self._send(code, body, ctype)
        if path == "/api/exports":
            files = sorted(EXPORTS.glob("*"), key=lambda p: p.stat().st_mtime, reverse=True)
            listing = [
                {
                    "name": f.name,
                    "size": f.stat().st_size,
                    "mtime": datetime.fromtimestamp(f.stat().st_mtime).isoformat(timespec="seconds"),
                    "url": f"/downloads/{f.name}",
                }
                for f in files
                if f.is_file()
            ]
            code, body, ctype = json_bytes({"files": listing})
            return self._send(code, body, ctype)
        if path.startswith("/downloads/"):
            name = Path(path).name
            target = EXPORTS / name
            if not target.exists() or not target.is_file():
                return self._send(404, b"not found", "text/plain")
            data = target.read_bytes()
            return self._send(
                200,
                data,
                "application/octet-stream",
                {"Content-Disposition": f'attachment; filename="{name}"'},
            )
        return super().do_GET()

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        payload = self._read_json()
        try:
            if path == "/api/memories":
                items = payload.get("memories")
                if not isinstance(items, list):
                    code, body, ctype = json_bytes({"error": "memories deve ser uma lista"}, 400)
                    return self._send(code, body, ctype)
                save_memories(items)
                code, body, ctype = json_bytes({"ok": True, "count": len(items)})
                return self._send(code, body, ctype)

            if path == "/api/export":
                return self._handle_export(payload)

            if path == "/api/chat":
                return self._handle_chat(payload)

            code, body, ctype = json_bytes({"error": "rota desconhecida"}, 404)
            return self._send(code, body, ctype)
        except Exception as exc:
            code, body, ctype = json_bytes({"error": str(exc)}, 500)
            return self._send(code, body, ctype)

    def _handle_export(self, payload: dict):
        fmt = str(payload.get("format") or "md").lower().lstrip(".")
        content = payload.get("content") or ""
        title = payload.get("title") or "export"
        if not content.strip():
            code, body, ctype = json_bytes({"error": "conteúdo vazio"}, 400)
            return self._send(code, body, ctype)
        if fmt not in EXPORT_HANDLERS:
            code, body, ctype = json_bytes(
                {"error": f"formato não suportado: {fmt}", "supported": sorted(EXPORT_HANDLERS)},
                400,
            )
            return self._send(code, body, ctype)
        ext, writer = EXPORT_HANDLERS[fmt]
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        filename = f"{safe_filename(title)}-{stamp}{ext}"
        dest = EXPORTS / filename
        writer(dest, content, title)
        code, body, ctype = json_bytes(
            {
                "ok": True,
                "filename": filename,
                "path": str(dest),
                "url": f"/downloads/{filename}",
                "size": dest.stat().st_size,
            }
        )
        return self._send(code, body, ctype)

    def _handle_chat(self, payload: dict):
        provider = str(payload.get("provider") or "").lower()
        if provider not in PROVIDERS:
            code, body, ctype = json_bytes({"error": "fornecedor inválido"}, 400)
            return self._send(code, body, ctype)
        api_key = (payload.get("api_key") or "").strip()
        if not api_key:
            code, body, ctype = json_bytes({"error": "API key em falta"}, 400)
            return self._send(code, body, ctype)
        messages = payload.get("messages") or []
        model = payload.get("model") or PROVIDERS[provider]["model"]
        use_cn = bool(payload.get("use_cn"))
        meta = PROVIDERS[provider]
        base = meta.get("base_cn") if use_cn and meta.get("base_cn") else meta["base"]
        url = base.rstrip("/") + "/chat/completions"
        body_req = json.dumps(
            {
                "model": model,
                "messages": messages,
                "stream": False,
                "temperature": float(payload.get("temperature") or 0.7),
            }
        ).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body_req,
            method="POST",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                raw = resp.read()
            data = json.loads(raw.decode("utf-8"))
            text = (
                data.get("choices", [{}])[0]
                .get("message", {})
                .get("content")
                or ""
            )
            code, body, ctype = json_bytes({"ok": True, "text": text, "raw": data})
            return self._send(code, body, ctype)
        except urllib.error.HTTPError as err:
            detail = err.read().decode("utf-8", errors="replace")[:2000]
            code, body, ctype = json_bytes(
                {"error": f"HTTP {err.code}", "detail": detail}, 502
            )
            return self._send(code, body, ctype)
        except Exception as exc:
            code, body, ctype = json_bytes({"error": str(exc)}, 502)
            return self._send(code, body, ctype)

    def log_message(self, fmt: str, *args):
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {fmt % args}")


def main():
    port = int(os.environ.get("PORT", "8765"))
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"AI Hub local → http://127.0.0.1:{port}")
    print("Ctrl+C para sair.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nA encerrar.")
        server.server_close()


if __name__ == "__main__":
    main()
