# AI Hub Local

Página web local para trabalhar com **Qwen**, **DeepSeek**, **GLM / Z.ai** e **Mistral** com:

- memória persistente (criar, activar, gravar em disco)
- composição / injecção de memória no prompt
- atalhos para os chats oficiais
- monitor de respostas com detecção de blocos de código
- exportação local para Markdown, DOCX, XLSX, PDF, Python, Java e dezenas de extensões

## Limite importante (iframes)

Os chats oficiais **não deixam embedding fiável**:

| Serviço | URL | Bloqueio típico |
|---|---|---|
| Qwen | https://chat.qwen.ai | X-Frame-Options / CSP |
| DeepSeek | https://chat.deepseek.com | X-Frame-Options |
| GLM | https://chat.z.ai e https://chatglm.cn | CSP / login |
| Mistral | https://chat.mistral.ai | `frame-ancestors 'none'` + `X-Frame-Options: DENY` |

Por isso o hub **abre os chats noutra janela** e deixa-te copiar o prompt já com memória. Para monitorizar e converter automaticamente, cola a resposta no separador *Monitor* **ou** usa o *Chat via API* (aí o servidor local vê o texto).

Não uses um proxy que remova headers de segurança dos sites oficiais: quebra autenticação, viola termos de uso e é frágil.

## Arranque

```bash
cd ai-hub-local
python3 server.py
```

Abre http://127.0.0.1:8765

Porta alternativa: `PORT=9000 python3 server.py`

Dependências Python já usadas pelo servidor: `python-docx`, `openpyxl`, `reportlab` (stdlib para o HTTP).

## Fluxo recomendado com os chats oficiais

1. Cria memórias à esquerda e marca as activas.
2. Escreve o pedido no compositor.
3. *Gerar prompt com memória* → *Copiar*.
4. Abre Qwen / DeepSeek / GLM / Mistral e cola.
5. Copia a resposta para *Monitor / Exportar*.
6. *Analisar resposta* gera um cartão por bloco ` ```linguagem `.
7. Exporta o bloco ou o texto inteiro.

## Fluxo com API (memória injectada de verdade)

1. Obtém chaves:
   - Qwen: DashScope / Bailian
   - DeepSeek: platform.deepseek.com
   - GLM: open.bigmodel.cn ou z.ai
   - Mistral: console.mistral.ai
2. Guarda-as em *Chaves API* (ficam no `localStorage` deste browser).
3. Em *Chat via API* as memórias activas vão no `system`.
4. *Última resposta → Monitor* para gerar ficheiros.

## Onde ficam os ficheiros

- Memórias em disco: `data/memories.json`
- Exportações: `exports/` e também descarregadas no browser via `/downloads/...`

Formatos: `md`, `txt`, `py`, `java`, `js`, `ts`, `html`, `css`, `json`, `csv`, `sql`, `xml`, `yaml`, `sh`, `rs`, `go`, `c`, `cpp`, `kt`, `swift`, `rb`, `php`, `r`, `docx`, `xlsx`, `pdf`.
